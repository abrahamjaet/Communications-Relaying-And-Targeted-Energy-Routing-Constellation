import numpy as np
from csltk import cr3bp
from csltk.utilities import emSystem
from csltk.utilities import find_equal_arclength_nodes
import matplotlib.pyplot as plt
from scipy.linalg import null_space


class SingleShooter:


    @staticmethod
    def fixed_time(x0, system, tol=1E-10, num_tries=200):
        initial_guess = x0

        try_num = 0
        normFHist = np.empty([num_tries, 1])
        Vi = initial_guess

        while try_num < num_tries:
            soln = cr3bp.propagate(system, Vi[0:6], np.array([0, Vi[-1]]))

            F = soln.y[:6, -1] - soln.y[:6, 0]
            normFHist[try_num] = np.linalg.norm(F)

            if np.linalg.norm(F) < tol:
                break

            x_end = soln.y[0:6, -1]
            DF = soln.y[6:, -1].reshape(6, 6) - np.eye(6)
            Vi[:6] -= DF.T.dot(np.linalg.inv(DF.dot(DF.T)).dot(F))

            print(try_num, normFHist[try_num])
            try_num += 1

        initial_cond = Vi[0:6]
        period = Vi[6]
        return initial_cond, period, normFHist[:try_num]

    @staticmethod
    def variable_time(x0, system, tol=1E-10, num_tries=200):
        initial_guess = x0

        try_num = 0
        normFHist = np.empty([num_tries, 1])
        Vi = initial_guess

        while try_num < num_tries:
            soln = cr3bp.propagate(system, Vi[0:6], np.array([0, Vi[-1]]))

            F = soln.y[0:6, -1] - soln.y[0:6, 0]
            normFHist[try_num] = np.linalg.norm(F)

            if np.linalg.norm(F) < tol:
                break

            x_end = soln.y[0:6, -1]
            dU, _ = cr3bp.uDerivatives(system.mu, x_end)
            dxdt = np.vstack([x_end[3:6].reshape([-1, 1]), 2 * x_end[4] + dU['Ux'], -2 * x_end[3] + dU['Uy'], dU['Uz']])
            DF = np.hstack([soln.y[6:, -1].reshape(6, 6) - np.eye(6), dxdt])
            Vi = Vi - DF.T.dot(np.linalg.inv(DF.dot(DF.T)).dot(F))

            print(try_num, normFHist[try_num])
            try_num += 1

        initial_cond = Vi[0:6]
        period = Vi[6]
        return initial_cond, period, normFHist[:try_num]

    @staticmethod
    def mirror_variable_time(x0, system, tol=1E-10, num_tries=200):
        initial_guess = x0

        try_num = 0
        normFHist = np.empty([num_tries, 1])
        Vi = initial_guess[np.r_[4, 6]]

        while try_num < num_tries:
            initial_guess[np.r_[4, 6]] = Vi
            soln = cr3bp.propagate(system, initial_guess[0:6], np.array([0, initial_guess[-1]]))

            F = soln.y[np.r_[3, 1], -1]
            normFHist[try_num] = np.linalg.norm(F)

            if np.linalg.norm(F) < tol:
                break

            x_end = soln.y[0:6, -1]
            dU, _ = cr3bp.uDerivatives(system.mu, x_end)
            dxdt = np.vstack([-2 * x_end[3] + dU['Uy'], 2 * x_end[4] + dU['Ux']])
            STM = soln.y[6:, -1].reshape(6, 6)
            DF = np.hstack([STM[np.r_[3, 1], np.r_[4, 1]].reshape([-1, 1]), dxdt])
            # Vi = Vi - DF.T.dot(np.linalg.inv(DF.dot(DF.T)).dot(F))
            Vi = Vi - np.linalg.inv(DF).dot(F)

            print(try_num, normFHist[try_num])
            try_num += 1

        initial_guess[np.r_[4, 6]] = Vi
        initial_cond = initial_guess[0:6]
        period = initial_guess[6]
        return initial_cond, period * 2, normFHist[:try_num]


def multiple_shooter_variable_time(initial_guess, system, nodes, tol=1E-10, num_tries=200):
    Vi = initial_guess
    normF_hist = np.empty(1, 100)

    try_num = 1
    while try_num < num_tries:
        F = np.empty([6 * (nodes.shape[0] - 1), 1])
        DF = np.empty([6 * (nodes.shape[0] - 1), 6 * (nodes.shape[0] - 1)])

        for i, node in enumerate(nodes):
            segmentGuess = Vi[6 * i:6 * (i + 1)]
            segmentTraj = cr3bp.propagate(system, segmentGuess[0:6], [0, segmentGuess[6]])
            F[5 * i:5 * (i + 1)] = segmentTraj.y[0:6, -1] - segmentTraj.y[0:6, 0]

            STM = segmentTraj.y[6:, -1].reshape([6, 6])
            x_end = segmentTraj.y[0:6, -1]
            dU, _ = cr3bp.uDerivatives(system.mu, x_end)
            dxdt = np.vstack([x_end[3:6].reshape([-1, 1]), 2 * x_end[4] + dU['Ux'], -2 * x_end[3] + dU['Uy'], dU['Uz']])

            if i != nodes.shape[0] - 1:
                DF[5 * i:5 * (i + 1), 6 * i:6 * (i + 2) - 1] = np.hstack([STM, dxdt, -1 * np.eye(6)])
            else:
                DF[5 * i:5 * (i + 1), 6 * i:6 * i + 1] = np.hstack([STM, dxdt])

        normF_hist[try_num - 1] = np.linalg.norm(F)
        if np.linalg.norm(F) <= tol:
            break

        Vi = Vi - DF.T.dot(np.linalg.inv(DF.dot(DF.T)).dot(F))
        try_num += 1

    if try_num == num_tries:
        print('No Convergence')
        return 0, 0, 0
    else:
        Vi = Vi[0:6]
        return Vi, normF_hist


class Continuation:

    @staticmethod
    def contruct_family(initial_periodic_orbit, t, system, num_orbits, delta_s=1E-3, tol=1E-10, num_tries=50,
                        spacing='time', direction=1, num_nodes=10, plotter=True):

        # UNDER CONSTRUCTION

        soln1 = cr3bp.propagate(system, initial_periodic_orbit, np.array([0, t]), dense=True)
        if spacing.lower() == 'arclength':
            t_nodes, nodes = find_equal_arclength_nodes(soln1, num_nodes)
        elif spacing.lower() == 'time':
            t_pts = np.linspace(0, t, num_nodes, endpoint=False)
            nodes = cr3bp.propagate(system, initial_periodic_orbit, np.array([0, t]), t_pts)
            node_states = nodes.y
            node_times = nodes.t
            node_tofs = np.hstack([np.diff(node_times), t - node_times[-1]])
        else:
            raise ValueError("spacing must either be 'arclength' or 'time', not {}".format(spacing))

        if plotter:
            ax = emSystem.plot_system()
            plt.sca(ax)
            ax.plot(soln1.y[0, :], soln1.y[1, :], soln1.y[2, :])
            ax.scatter(node_states[0, :], node_states[1, :], node_states[2, :])
            plt.ion()
            plt.show()

        # Nodes contains nodes to step along the nullspace for multiple-shooting corrections
        orbit_initial_conditions = np.empty([num_orbits, 6])
        orbit_initial_conditions[0, :] = initial_periodic_orbit
        computed_orbits = 0
        new_nodes = nodes

        while computed_orbits < num_orbits:
            print('Computing Orbit {0} out of {1}'.format(computed_orbits + 1, num_orbits))

            DF = np.zeros([6 * (num_nodes + 1), 7 * num_nodes])
            for i, Vi in enumerate(node_states.T, 0):
                dU, _ = cr3bp.uDerivatives(system.mu, Vi[0:6])
                dxdt = np.vstack([Vi[3:6].reshape([-1, 1]), 2 * Vi[4] + dU['Ux'], -2 * Vi[3] + dU['Uy'], dU['Uz']])
                STM = Vi[6:].reshape([6, 6])
                I = np.eye(6)
                if i != num_nodes - 1:
                    DF[6 * i:6 * (i + 1), 7 * i:7 * (i + 2) - 1] = np.hstack([STM, dxdt, -1 * I])
                else:
                    DF[6 * i:6 * (i + 1), 7 * i:] = np.hstack([STM, dxdt])

            n = direction * null_space(DF)
            if n.shape[1] > 1:
                pos_per_growth = n[-1, :] > 0
                n = n[:, pos_per_growth]
            try_num = 0
            V_prev = orbit_initial_conditions[computed_orbits, :]
            Vi = (V_prev + delta_s * n.T).squeeze()

            # if spacing.lower() == 'arclength':
            #     t_nodes, nodes = find_equal_arclength_nodes(Vi, 10)
            # elif spacing.lower() == 'time':
            #     nodes = find_equal_time_nodes(initial_periodic_orbit, t, 8)
            # else:
            #     raise ValueError("spacing must either be 'arclength' or 'time', not {}".format(spacing))

    @staticmethod
    def psuedo_arclength(initlal_periodic_orbit, system, num_orbits, delta_s=1E-3, direction=1, tol=1E-10,
                         num_tries=20):
        orbit_initial_conditions = np.empty([num_orbits + 1, 7])
        orbit_initial_conditions[0, :] = initlal_periodic_orbit

        computed_orbits = 0

        while computed_orbits < num_orbits:
            print('Computing Orbit {0} out of {1}'.format(computed_orbits + 1, num_orbits))
            redo_last_orbit = False
            Vi = orbit_initial_conditions[computed_orbits, :]
            soln = cr3bp.propagate(system, Vi[0:6], np.array([0, Vi[-1]]))

            dU, _ = cr3bp.uDerivatives(system.mu, Vi[0:6])
            dxdt = np.vstack([Vi[3:6].reshape([-1, 1]), 2 * Vi[4] + dU['Ux'], -2 * Vi[3] + dU['Uy'], dU['Uz']])
            STM = soln.y[6:, -1].reshape([6, 6])

            I = np.eye(6)

            # This is for a specific constraint - need to generalize this
            # DFd = np.vstack([np.hstack([STM[np.r_[0:4, 5], :] - I[np.r_[0:4, 5], :], dxdt[np.r_[0:4, 5]]]),
            #                  np.array([0, 1, 0, 0, 0, 0, 0])])

            DFd = np.hstack([STM - I, dxdt])

            n = direction * null_space(DFd)

            if n.shape[1] > 1:
                if direction > 0:
                    pos_per_growth = np.argmax(
                        n[-1, :])  # Need to pick one.. so pick the one that grows the period the most
                else:
                    pos_per_growth = np.argmin(
                        n[-1, :])  # Need to pick one.. so pick the one that shrinks the period the most
                n = n[:, pos_per_growth]

            try_num = 0
            V_prev = orbit_initial_conditions[computed_orbits, :]
            Vi = (V_prev + delta_s * n.T).squeeze()

            while try_num < num_tries:
                soln = cr3bp.propagate(system, Vi[0:6], np.array([0, Vi[6]]))
                # H = np.vstack([(soln.y[np.r_[0:4, 5], -1] - soln.y[np.r_[0:4, 5], 0]).reshape([-1, 1]), soln.y[1, 0],
                # (Vi - V_prev).T.dot(n) - delta_s])

                H = np.vstack([(soln.y[0:6, -1] - soln.y[0:6, 0]).reshape([-1, 1]),
                               (Vi - V_prev).T.dot(n) - delta_s])

                if np.linalg.norm(H) < tol:
                    print('Moving on...')
                    break

                x_end = soln.y[0:6, -1]
                dxdt = np.vstack(
                    [x_end[3:6].reshape([-1, 1]), 2 * x_end[4] + dU['Ux'], -2 * x_end[3] + dU['Uy'], dU['Uz']])
                dU, _ = cr3bp.uDerivatives(system.mu, x_end)
                STM = soln.y[6:, -1].reshape([6, 6])

                # DH = np.vstack([np.hstack([STM[np.r_[0:4, 5], :] - I[np.r_[0:4, 5], :], dxdt[np.r_[0:4, 5]]]),
                #                 np.array([0, 1, 0, 0, 0, 0, 0]), n.T])
                DH = np.vstack([np.hstack([STM - I, dxdt]), n.T])

                Vi = Vi - np.linalg.inv(DH).dot(H).T
                Vi = Vi.squeeze()

                try_num += 1

            # if np.abs(Vi[0] - orbit_initial_conditions[computed_orbits, 0]) > 2 * delta_s:
            #     print('Reducing Step Size...',np.abs(Vi[0] - orbit_initial_conditions[computed_orbits, 0]))
            #     delta_s = delta_s / 2
            #     redo_last_orbit = True

            orbit_initial_conditions[computed_orbits + 1, 0:6] = Vi[0:6]
            orbit_initial_conditions[computed_orbits + 1, 6] = Vi[6]

            if not redo_last_orbit:
                computed_orbits += 1
        return orbit_initial_conditions

    @staticmethod
    def natural_parameter(initlal_periodic_orbit, system, num_orbits, delta_p=1E-5, direction=1, tol=1E-10,
                          num_tries=50):
        orbit_initial_conditions = np.empty([num_orbits + 1, 7])
        orbit_initial_conditions[0, :] = initlal_periodic_orbit

        computed_orbits = 0

        while computed_orbits < num_orbits:
            print('Computing Orbit {0} out of {1}'.format(computed_orbits + 1, num_orbits))
            try_num = 0
            Vi = orbit_initial_conditions[computed_orbits, :] + np.array([0, 0, 0, 0, 0, 0, delta_p])

            corr_Vi, corrT, _ = SingleShooter.mirror_variable_time(np.hstack([Vi[0:6], Vi[6] / 2]), system)

            orbit_initial_conditions[computed_orbits + 1, 0:6] = corr_Vi
            orbit_initial_conditions[computed_orbits + 1, 6] = corrT
            computed_orbits += 1

        return orbit_initial_conditions


if __name__ == '__main__':
    # x0 = np.array([0.82340, 0, -0.026755, 0, 0.13742, 0])
    # T0 = 2.7477
    #
    # initGuess = np.hstack([x0, T0])
    # corr_x0, corr_T, normF = SingleShooter.variable_time(initGuess, emSystem)
    # print(corr_x0, corr_T)

    x0c = np.array(
        [0.823405290397912, 0.00091910994288058, -0.0267338490559914, 0.000785910082175323, 0.137389232870076,
         0.000772284793273442, 2.74776761743665])
    print('Continuing Family...')

    familiy_initial_conditions = Continuation.psuedo_arclength(x0c, emSystem, 50, 1E-2)
    ax = emSystem.plot_system()

    print(familiy_initial_conditions.shape)

    for init_conds in familiy_initial_conditions:
        halo = cr3bp.propagate(emSystem, init_conds[0:6], np.array([0, init_conds[-1]]),
                               np.sort(np.linspace(0, init_conds[-1], 500)))
        plt.sca(ax)
        ax.plot(halo.y[0, :], halo.y[1, :], halo.y[2, :])

    plt.xlim([0.82, 0.9])
    plt.ylim([-0.15, 0.15])
    ax.set_zlim([-0.12, 0.08])
    plt.show()
