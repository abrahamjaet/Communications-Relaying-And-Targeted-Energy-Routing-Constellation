import numpy as np
from math import sqrt
from scipy.integrate import solve_ivp
from extensisq import SWAG


def dynamics_wSTM(t, x0, mu):
    x, y, z, xdot, ydot, zdot = x0[0:6]

    du, ddu = uDerivatives(mu, x0[0:5])

    # if len(x0) > 6:
    STM = x0[6:].reshape([6, 6])
    A = np.array([[0, 0, 0, 1, 0, 0],
                  [0, 0, 0, 0, 1, 0],
                  [0, 0, 0, 0, 0, 1],
                  [ddu['Uxx'], ddu['Uxy'], ddu['Uxz'], 0, 2, 0],
                  [ddu['Uxy'], ddu['Uyy'], ddu['Uyz'], -2, 0, 0],
                  [ddu['Uxz'], ddu['Uyz'], ddu['Uzz'], 0, 0, 0]])
    stmDot = np.matmul(A, STM)

    xddot = 2 * ydot + du['Ux']
    yddot = -2 * xdot + du['Uy']
    zddot = du['Uz']

    dydt = np.array([xdot, ydot, zdot, xddot, yddot, zddot])
    dydt = np.concatenate([dydt, stmDot.reshape([1, -1]).squeeze()])
    return dydt

def dynamics(t, x0, mu):
    x, y, z, xdot, ydot, zdot = x0[0:6]

    du, ddu = uDerivatives(mu, x0[0:5])

    # if len(x0) > 6:
    A = np.array([[0, 0, 0, 1, 0, 0],
                  [0, 0, 0, 0, 1, 0],
                  [0, 0, 0, 0, 0, 1],
                  [ddu['Uxx'], ddu['Uxy'], ddu['Uxz'], 0, 2, 0],
                  [ddu['Uxy'], ddu['Uyy'], ddu['Uyz'], -2, 0, 0],
                  [ddu['Uxz'], ddu['Uyz'], ddu['Uzz'], 0, 0, 0]])

    xddot = 2 * ydot + du['Ux']
    yddot = -2 * xdot + du['Uy']
    zddot = du['Uz']

    dydt = np.array([xdot, ydot, zdot, xddot, yddot, zddot])
    return dydt


def uDerivatives(mu, x):
    r1 = sqrt(x[1] ** 2 + (x[0] + mu) ** 2 + x[2] ** 2)
    r2 = sqrt((x[0] - 1 + mu) ** 2 + x[1] ** 2 + x[2] ** 2)

    r1cube = r1 ** 3
    r1quint = r1 ** 5

    r2cube = r2 ** 3
    r2quint = r2 ** 5

    Ux = x[0] - ((1 - mu) * (x[0] + mu)) / r1cube - (mu * (x[0] - 1 + mu)) / r2cube
    Uy = x[1] - ((1 - mu) * x[1]) / r1cube - (mu * x[1]) / r2cube
    Uz = -((1 - mu) * x[2]) / r1cube - mu * x[2] / r2cube

    Uxx = 1 - ((1 - mu) / r1cube) - (mu / r2cube) + (3 * (1 - mu) * (x[0] + mu) ** 2) / r1quint + (
            (3 * mu * (x[0] - 1 + mu) ** 2) / r2quint)
    Uyy = 1 - ((1 - mu) / r1cube) - (mu / r2cube) + (3 * (1 - mu) * (x[1] ** 2)) / r1quint + (
            3 * mu * (x[1] ** 2)) / r2quint
    Uzz = (-(1 - mu) / r1cube) - (mu / r2cube) + (3 * (1 - mu) * (x[2] ** 2)) / r1quint + (
            3 * mu * (x[2] ** 2)) / r2quint
    Uxy = (3 * (1 - mu) * (x[0] + mu) * x[1]) / r1quint + (3 * mu * (x[0] - 1 + mu) * x[1]) / r2quint
    Uxz = (3 * (1 - mu) * (x[0] + mu) * x[2]) / r1quint + (3 * mu * (x[0] - 1 + mu) * x[2]) / r2quint
    Uyz = (3 * (1 - mu) * x[1] * x[2]) / r1quint + (3 * mu * x[1] * x[2]) / r2quint

    dU = {}
    dU['Ux'] = Ux
    dU['Uy'] = Uy
    dU['Uz'] = Uz

    dUU = {}
    dUU['Uxx'] = Uxx
    dUU['Uyy'] = Uyy
    dUU['Uzz'] = Uzz
    dUU['Uxy'] = Uxy
    dUU['Uxz'] = Uxz
    dUU['Uyz'] = Uyz

    return dU, dUU


def propagate(system, x0, t_span, eval_times=None, rel_tol=1E-13, abs_tol=1E-13, dense=False, events=None, STM=True):

    # Propagate STM or not
    if STM:
        stm0 = np.eye(6)
        x0 = np.concatenate([x0, stm0.reshape([1, -1]).squeeze()])
        odefunc = lambda t, y: dynamics_wSTM(t, y, system.mu)
    else:
        odefunc = lambda t, y: dynamics(t, y, system.mu)

    if eval_times is not None:
        sol = solve_ivp(odefunc, t_span, x0, method=SWAG, t_eval=eval_times, rtol=rel_tol,
                        atol=abs_tol, dense_output=dense, events=events)
    else:
        sol = solve_ivp(odefunc, t_span, x0, method=SWAG, rtol=rel_tol, atol=abs_tol,
                        dense_output=dense, events=events)

    return sol


def jacobiConstant(state, mu):
    r1 = lambda y: sqrt(y[1] ** 2 + (y[0] + mu) ** 2 + y[2] ** 2)
    r2 = lambda y: sqrt((y[0] - 1 + mu) ** 2 + y[1] ** 2 + y[2] ** 2)
    jC = state[0] ** 2 + state[1] ** 2 + 2 * (1 - mu) / r1(state) + 2 * mu / r2(state) - sum(x ** 2 for x in state[3:])
    return jC


if __name__ == '__main__':
    from csltk.utilities import emSystem

    li = emSystem.li
    print(propagate(emSystem, [0.4, 0.03, 0, 0.05, .1, 0], (0, 1), STM=False))
