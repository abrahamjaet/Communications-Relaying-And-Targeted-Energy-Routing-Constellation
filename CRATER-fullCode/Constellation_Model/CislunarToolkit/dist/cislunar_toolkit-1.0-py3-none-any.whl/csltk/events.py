import numpy as np


class Events:

    @staticmethod
    def moon_intersection(t, y, system):
        moon_radius = 1737 / system.lstar
        dist_from_moon = y[:3] - np.array([1 - system.mu, 0, 0])
        impact = np.linalg.norm(dist_from_moon) - moon_radius
        # if impact < 0: print('Impacted Moon')
        return impact

    @staticmethod
    def earth_intersection(t, y, system):
        earth_radius = 6378 / system.lstar
        dist_from_earth = y[:3] - np.array([-1 * system.mu, 0, 0])
        impact = np.linalg.norm(dist_from_earth) - earth_radius
        # if impact < 0: print('Impacted Earth')
        return impact


Events.earth_intersection.terminal = True
Events.moon_intersection.terminal = True
