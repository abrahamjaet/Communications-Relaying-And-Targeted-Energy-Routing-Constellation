import requests
import json
import numpy as np
import matplotlib.pyplot as plt

from csltk.orbits import PeriodicOrbit
from csltk.utilities import System

# documentation for this request is at
# https://ssd-api.jpl.nasa.gov/doc/periodic_orbits.html 
httpsource = 'https://ssd-api.jpl.nasa.gov/periodic_orbits.api'


class JPLFamily:

    def __new__(cls, *args, **kwargs):
        cls.orbits = []
        cls.min_stab = None
        cls.max_stab = None
        cls.min_Cj = None
        cls.max_Cj = None
        cls.min_T = None
        cls.max_T = None
        return super().__new__(cls)

    def __init__(self, sys='earth-moon', fam='halo', libr='1', branch='N', period_units='TU'):
        self.sys = sys
        self.fam = fam
        self.libr = libr
        self.branch = branch
        self.period_units = period_units

    def set_stab_bounds(self, min_stab, max_stab):
        self.min_stab = min_stab
        self.max_stab = max_stab

    def set_jacobi_bounds(self, min_Cj, max_Cj):
        self.min_Cj = min_Cj
        self.max_Cj = max_Cj

    def set_period_bounds(self, min_T, max_T):
        self.min_T = min_T
        self.max_T = max_T

    def set_system(self, sys: str):
        self.sys = sys

    def set_po_family(self, family: str):
        self.fam = family

    def set_libration(self, libr: str):
        self.libr = libr

    def set_branch(self, branch: str):
        self.branch = branch

    def request(self):
        request = self._getReqLink()
        data = requests.get(request)

        self._badResponseCode(data.status_code)
        data = json.loads(data.text)

        if 'warning' in data:
            print('Try using the following limits!\n')
            print(data['limits'])
            raise RuntimeError(data['warning'])
        
        if 'message' in data:
            raise RuntimeError(data['message'])

        sys_name = data['system']['name']
        mu = data['system']['mass_ratio']
        fam_name = data['family']

        if 'libration_point' in data:
            lib_name = data['libration_point']
        else:
            lib_name = 'none'

        if 'branch' in data:
            branch = data['branch']
        else:
            branch = 'none'

        orbit_data = data['data']

        for orbit in orbit_data:
            orbit = [float(x) for x in orbit]
            iState = np.array(orbit[0:6])
            Cj = orbit[6]
            T = orbit[7]
            stab = orbit[8]
            systemValues = {'mu': float(mu), 'lstar': float(data['system']['lunit']), 'tstar': float(data['system']['tunit'])}
            system = System(**systemValues)
            p = PeriodicOrbit(iState=iState,system=system, Cj=Cj, T=T, stab=stab)
            # p.system = sys_name
            p.mu = mu
            p.family = fam_name
            p.libr = lib_name
            p.branch = branch


            self.orbits.append(p)

        return self.orbits

    def get_orbits(self):
        return self.orbits

    def _getReqLink(self):
        '''
        form with (appending to httpsource)
        '?sys=<1>&family=<2>libr=<3>&branch=<4>&periodmax=<5>&stabmax=<6>&jacobimin=<7>'
            ___        ___     ___        ___           ___         ___           ___
        1. sys: 3bp gravitational system 'primary-secondary'
            'earth-moon'
        2. family: orbit family
            'halo', 'vertical', 'axial', 'lyapunov', 'longp', 'short', 'butterfly',
            'dragonfly', 'resonant', 'dro', 'dpo', 'lpo'
        3. libr: libration point
            '1', '2', '3', '4', '5'
            -> REQUIRED FOR THESE FAMILIES:
                lyapunov, halo: 1,2,3
                longp, short: 4,5
                axial, vertical: 1,2,3,4,5
        4. branch:
            'N', 'S', 'E', 'W', '<#>'
            -> REQUIRED FOR THESE FAMILIES:
                halo, dragonfly, butterfly: N,S
                lpo,: E,W
                resonant: integer sequence
        5. (period)
            a) periodmax
            b) periodmin
            c) periodunits
                's', 'h', 'd', 'TU'
        6. (stability index)
            a) stabmax
            b) stabmin
        7. (jacobi constant)
            a) jacobimax
            b) jacobimin
        '''

        req = httpsource + '?' + 'sys=' + self.sys + '&family=' + self.fam + '&periodunits=' + self.period_units

        if ('halo' in req) or ('lyapunov' in req) or ('longp' in req) or ('short' in req) or ('axial' in req) or (
                'vertical' in req):
            req = req + '&libr=' + self.libr
        if 'halo' in req or 'dragonfly' in req or 'butterfly' in req or 'lpo' in req or 'resonant' in req:
            req = req + '&branch=' + self.branch

        if self.min_T and self.max_T:
            req = req + '&periodmax=' + str(self.max_T) + '&periodmin=' + str(self.min_T)
        
        if self.min_stab and self.max_stab:
            req = req + '&stabmax=' + str(self.max_stab) + '&stabmin=' + str(self.min_stab)

        if self.min_Cj and self.max_Cj:
            req = req + '&jacobimax=' + str(self.max_Cj) + '&jacobimin=' + str(self.min_Cj)

        retFlags = self._checkRequest(req)

        if len(retFlags) > 0:
            for msg in retFlags:
                print(msg)

        return req

    def _checkRequest(self, requestLink):
        '''
        Checks whether the request (string url requestLink) is valid.
        The request return will give an id corresponding to validity of request,
        but this instead alerts the user what will go wrong before requesting
        '''

        msgs = []

        # family strings
        familyHalo = 'family=halo' in requestLink
        familyLyap = 'family=lyapunov' in requestLink
        familyDragon = 'family=dragonfly' in requestLink
        familyButter = 'family=butterfly' in requestLink
        familyLongp = 'family=longp' in requestLink
        familyShort = 'family=short' in requestLink
        familyAxial = 'family=axial' in requestLink
        familyVert = 'family=vertical' in requestLink
        familyLpo = 'family=lpo' in requestLink
        familyRes = 'family=resonant' in requestLink

        # libr strings
        libr1 = 'libr=1' in requestLink
        libr2 = 'libr=2' in requestLink
        libr3 = 'libr=3' in requestLink
        libr4 = 'libr=4' in requestLink
        libr5 = 'libr=5' in requestLink

        # branch strings
        branchN = 'branch=N' in requestLink
        branchS = 'branch=S' in requestLink
        branchE = 'branch=E' in requestLink
        branchW = 'branch=W' in requestLink

        # period strings
        pdMax = 'periodmax=' in requestLink
        pdMin = 'periodmin=' in requestLink
        pdUnit = 'periodunits=' in requestLink

        # Check that orbit family is coupled with libration point and branch
        if familyHalo:
            librGood = (libr1 or libr2 or libr3)
            if not librGood:
                msgs.append('Libration Point 1-3 not defined for Halo Orbit')
            branchGood = (branchN or branchS)
            if not branchGood:
                msgs.append('Orbit Branch (N/S) not defined for Halo Orbit')
        elif familyLyap:
            librGood = (libr1 or libr2 or libr3)
            if not librGood:
                msgs.append('Libration Point 1-3 not defined for Lyapunov Orbit')
        elif familyLongp:
            librGood = (libr4 or libr5)
            if not librGood:
                msgs.append('Libration Point 4-5 not defined for Long P Orbit')
        elif familyShort:
            librGood = (libr4 or libr5)
            if not librGood:
                msgs.append('Libration Point 4-5 not defined for Short Orbit')
        elif familyAxial:
            librGood = (libr1 or libr2 or libr3 or libr4 or libr5)
            if not librGood:
                msgs.append('Libration Point not defined for Axial Orbit')
        elif familyVert:
            librGood = (libr1 or libr2 or libr3 or libr4 or libr5)
            if not librGood:
                msgs.append('Libration Point not defined for Vertical Orbit')
        elif familyDragon:
            branchGood = (branchN or branchS)
            if not branchGood:
                msgs.append('Orbit Branch (N/S) not defined for Dragonfly Orbit')
        elif familyButter:
            branchGood = (branchN or branchS)
            if not branchGood:
                msgs.append('Orbit Branch (N/S) not defined for Butterfly Orbit')
        elif familyLpo:
            branchGood = (branchE or branchW)
            if not branchGood:
                msgs.append('Orbit Branch (E/W) not defined for LPO Orbit')
        elif familyRes:
            branchGood = ('branch=' in requestLink)
            if not branchGood:
                msgs.append('Orbit Branch (pq) not defined for Resonant Orbit')

        if pdMin or pdMax:
            if not pdUnit:
                msgs.append('Units not defined for period')
            else:
                unitsHere = requestLink.index('periodunits=') + len('periodunits=')
                char1 = requestLink[unitsHere]
                if char1 == 'T':
                    if requestLink[unitsHere + 1] != 'U':
                        msgs.append('Inappropriate units for period used')
                elif not (char1 == 's' or char1 == 'h' or char1 == 'd'):
                    msgs.append('Inappropriate units for period used')

        return msgs

    def _badResponseCode(self, statusCode):
        '''
        Print reasoning for request problems from string statusCode, from response.status_code
        '''
        if statusCode != 200:
            if statusCode == 400:
                print('Bad Request (invalild keywords and/or content)')
            elif statusCode == 405:
                print('Incorrect Method used in request')
            elif statusCode == 500:
                print('Internal Server Error: DB not available at time of request')
            elif statusCode == 503:
                print('Service Unavailable: Server unable to handle request at time of request')

if __name__ == '__main__':
    from csltk.orbits import PeriodicOrbitFamily

    fam = JPLFamily(fam='halo', libr='2')
    fam.set_stab_bounds(0.0, 2.0)
    orbits = fam.request()
    haloFam = PeriodicOrbitFamily(orbits)
    # haloFam.plot_parmeter('period')
    newPo = haloFam.interpolate_between_members('period',1.98)

    ax = newPo.plot()
    # ax = plt.show()


    orbits[0].plot(ax)
    plt.show()

    # for po in orbits[1:50:]:
    #     po.plot(ax)
    # plt.show()

    # print(orbits[0].iState)

    # print([po.T for po in orbits])
