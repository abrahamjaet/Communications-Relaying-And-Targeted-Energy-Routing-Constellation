import matplotlib.pyplot as plt
from scipy import interpolate
import numpy as np
from dataclasses import dataclass, field
from math import sqrt

from csltk import cr3bp
from csltk.correctors import SingleShooter
from csltk.utilities import System, rotate
from csltk.events import Events


@dataclass
class PeriodicOrbit:
    iState: np.ndarray
    system: System
    Cj: float
    T: float
    stab: float

    # system: str = 'earth-moon'
    # family: str = 'halo'
    # libr: str = '1'
    # branch: str = 'N'

    mu: float = 1.215058560962404e-02

    @property
    def states(self):
        IC = np.hstack([self.iState, self.T])
        corrX0, corrT0, _ = SingleShooter.variable_time(IC, self.system)
        self.T = corrT0
        self.iState = corrX0
        soln = cr3bp.propagate(self.system, corrX0, np.array([0, corrT0]))
        return np.vstack([soln.t, soln.y]).T

    @property
    def monodromy(self):
        states = self.states
        return states[-1, 7:].reshape(6, 6)

    def computeStability(self):
        pass

    def computeJacobiConstant(self):
        self.Cj = cr3bp.jacobiConstant(self.iState, self.system.mu)

    def correctInitialCondition(self, correctortype='variableTime'):
        IC = np.hstack([self.iState, self.T])
        if correctortype == 'variableTime':
            corrX0, corrT0, _ = SingleShooter.variable_time(IC, self.system)
        elif correctortype == 'fixedTime':
            corrX0, corrT0, _ = SingleShooter.fixed_time(IC, self.system)
        else:
            raise TypeError('Must choose "variableTime" or "fixedTime" corrector type')
        self.T = corrT0
        self.iState = corrX0
        return corrX0, corrT0

    def plot(self, ax=None):
        if ax is None:
            ax = self.system.plot_system()
        plt.sca(ax)

        states = self.states
        # 1,2, and 3 since row 0 is the times
        ax.plot(states[:, 1], states[:, 2], states[:, 3])
        return ax

    def findManifolds(self, perturbation=0.001):
        manifold = Manifolds(self, perturbation)
        return manifold


@dataclass
class PeriodicOrbitFamily:
    familyMembers: list[PeriodicOrbit]

    def interpolate_between_members(self, parameter: str, val: float):
        # This is to interpolate between members to find the correct member you desire, such as one with a specific
        # stability, period, ect
        corrector_type = 'variableTime'
        if parameter.lower() == 'period':
            parameter = 'T'
            parameters = np.array([getattr(fm, parameter) for fm in self.familyMembers]).T
            corrector_type = 'fixedTime'
        elif parameter.lower() == 'stability':
            parameter = 'stab'
            parameters = np.array([getattr(fm, parameter) for fm in self.familyMembers]).T
        elif parameter.lower() == 'member':
            parameter = 'n'
            parameters = np.arange(1, len(self.familyMembers))
        elif parameter.lower() == 'jacobi':
            parameter = 'Cj'
            parameters = np.array([getattr(fm, parameter) for fm in self.familyMembers]).T
        else:
            raise TypeError('You must choose "period", "stability" or "member" as an interpolation parameter')

        new_ic_interpolator = interpolate.interp1d(parameters, np.array([fm.iState.T for fm in self.familyMembers]),
                                                   axis=0)
        newIc = new_ic_interpolator(val)
        new_T_interpolator = interpolate.interp1d(parameters, [fm.T for fm in self.familyMembers])
        newT = new_T_interpolator(val)
        newOrb = PeriodicOrbit(newIc, self.familyMembers[0].system, 0, newT, 0)
        newOrb.computeJacobiConstant()
        newIc, newT = newOrb.correctInitialCondition(corrector_type)

        print(getattr(newOrb, parameter), val)
        return newOrb

    def plot_parameter(self, parameter):
        if parameter.lower() == 'period':
            parameter = 'T'
        elif parameter.lower() == 'stability':
            parameter = 'stab'
        elif parameter.lower() == 'member':
            parameter = 'n'
        elif parameter.lower() == 'jacobi':
            parameter = 'Cj'

        parameters = np.array([getattr(fm, parameter) for fm in self.familyMembers])
        plt.plot(parameters, '-o')
        plt.ylabel('{}'.format(parameter))
        plt.xlabel('Family Member')
        plt.show()


@dataclass
class Manifold:
    # Positive is perturbed in the +eigenvector directon, negative is perturbed in the negative eigenvector direction
    positive: np.ndarray
    negative: np.ndarray


@dataclass
class Manifolds:
    periodicOrbit: PeriodicOrbit
    stable: Manifold = field(init=False)
    unstable: Manifold = field(init=False)
    perturbation: float = 0.001

    def __post_init__(self):
        eigenvalues, eigenvectors = np.linalg.eig(self.periodicOrbit.monodromy)

        eigenvalues = np.round(eigenvalues, 4)

        unityEigenvalues = np.where(eigenvalues.real == 1)
        unstableEigenvalues = np.where(eigenvalues.real > 1)
        stableEigenvalues = np.where(np.logical_and(eigenvalues.real < 1, eigenvalues.imag == 0))

        unstableEigenvectors = eigenvectors[:, unstableEigenvalues].squeeze()
        stableEigenvectors = eigenvectors[:, stableEigenvalues].squeeze()


        # Need to understand why argmin on the stable gives the desired effect on the manifolds example
        biggestUnstable = np.argmax(eigenvalues[unstableEigenvalues].real)
        biggestStable = np.argmin(eigenvalues[stableEigenvalues].real)

        # unstableEigenvalues = np.where(np.real(eigenvalues) > 1)
        # # mUidx = np.argmax(eigenvalues[unstableEigenvalues])
        # mUidx = unstableEigenvalues
        # stableEigenvalues = np.where(np.logical_and(np.real(eigenvalues) < 1, np.imag(eigenvalues) == 0))
        # # mSidx = np.argmax(eigenvalues[stableEigenvalues])
        # mSidx = stableEigenvalues

        if np.ndim(unstableEigenvectors) == 1:
            unstableEv = unstableEigenvectors
        else:
            unstableEv = unstableEigenvectors[:, biggestUnstable]
        unstableEv = np.squeeze(unstableEv / np.linalg.norm(unstableEv[:3]))

        if np.ndim(stableEigenvectors) == 1:
            stableEv = stableEigenvectors
        else:
            stableEv = stableEigenvectors[:, biggestStable]
        stableEv = np.squeeze(stableEv / np.linalg.norm(stableEv[:3]))

        periodicOrbitStates = self.periodicOrbit.states
        unstablePositiveManifold = np.empty([periodicOrbitStates.shape[0], 6])
        unstableNegativeManifold = np.empty([periodicOrbitStates.shape[0], 6])
        stablePositiveManifold = np.empty([periodicOrbitStates.shape[0], 6])
        stableNegativeManifold = np.empty([periodicOrbitStates.shape[0], 6])

        for idx, state in enumerate(periodicOrbitStates):
            STM = state[7:].reshape(6, 6)
            unstableStep = STM.dot(unstableEv.real)
            stableStep = STM.dot(stableEv.real)

            # Normalize by position elements
            unstableStep = unstableStep / np.linalg.norm(unstableStep[:3])
            stableStep = stableStep / np.linalg.norm(stableStep[:3])

            if unstableStep[0] > 0:
                unstablePositiveManifold[idx, :] = state[1:7] + self.perturbation * unstableStep
                unstableNegativeManifold[idx, :] = state[1:7] - self.perturbation * unstableStep
            elif unstableStep[0] < 0:
                unstablePositiveManifold[idx, :] = state[1:7] - self.perturbation * unstableStep
                unstableNegativeManifold[idx, :] = state[1:7] + self.perturbation * unstableStep

            if stableStep[0] > 0:
                stablePositiveManifold[idx, :] = state[1:7] + self.perturbation * stableStep
                stableNegativeManifold[idx, :] = state[1:7] - self.perturbation * stableStep
            elif stableStep[0] < 0:
                stablePositiveManifold[idx, :] = state[1:7] - self.perturbation * stableStep
                stableNegativeManifold[idx, :] = state[1:7] + self.perturbation * stableStep

        self.stable = Manifold(stablePositiveManifold, stableNegativeManifold)
        self.unstable = Manifold(unstablePositiveManifold, unstableNegativeManifold)

    def plot(self, ax):
        if ax is None:
            ax = self.periodicOrbit.plot()
        plt.sca(ax)

        earth_impact = lambda t, y: Events.earth_intersection(t, y, self.periodicOrbit.system)
        moon_impact = lambda t, y: Events.moon_intersection(t, y, self.periodicOrbit.system)

        def earth_x(t, y):
            return y[0] + self.periodicOrbit.system.mu

        earth_x.terminal = True

        def moon_x(t, y):
            return y[0] - (1 - self.periodicOrbit.system.mu)

        moon_x.terminal = True

        for idx, _ in enumerate(self.stable.positive):
            if idx % 10 != 0:
                continue
            stablePositive = self.stable.positive[idx, :]
            stableNegative = self.stable.negative[idx, :]
            unstablePositive = self.unstable.positive[idx, :]
            unstableNegative = self.unstable.negative[idx, :]

            sPsoln = cr3bp.propagate(self.periodicOrbit.system, stablePositive, np.array([0, -10]),
                                     events=(earth_x, moon_x))
            sNsoln = cr3bp.propagate(self.periodicOrbit.system, stableNegative, np.array([0, -10]),
                                     events=(earth_x, moon_x))
            uPsoln = cr3bp.propagate(self.periodicOrbit.system, unstablePositive, np.array([0, 10]),
                                     events=(earth_x, moon_x))
            uNsoln = cr3bp.propagate(self.periodicOrbit.system, unstableNegative, np.array([0, 10]),
                                     events=(earth_x, moon_x))

            ax.plot(sPsoln.y[0, :], sPsoln.y[1, :], sPsoln.y[2, :], 'b-')
            ax.plot(sNsoln.y[0, :], sNsoln.y[1, :], sNsoln.y[2, :], 'b-')
            ax.plot(uPsoln.y[0, :], uPsoln.y[1, :], uPsoln.y[2, :], 'r-')
            ax.plot(uNsoln.y[0, :], uNsoln.y[1, :], uNsoln.y[2, :], 'r-')
        return ax


def resonant_orbit(system, p, q, ecc):
    moonT = 27.45 * 3600 * 24  # days -> seconds
    moonA = 384338.174  # km
    moonA = system.lstar

    orbit_sma = (((q ** 2) * (moonA ** 3)) / (p ** 2)) ** (1 / 3)
    r0 = (1 - ecc) * orbit_sma  # periapsis as starting magnitude
    v0 = (2 * system.p1.mu * ((1 / r0) - 1 / (2 * orbit_sma))) ** (1 / 2)
    x0 = np.array([r0, 0, 0, 0, v0, 0])

    x0cr3bp = rotate.intertial_to_rotating(x0, 0)
    T = (moonT * q) / system.tstar

    corr_x0, corr_T, normF = SingleShooter.mirror_variable_time(np.hstack([x0cr3bp, T / 2]), emSystem, 1E-10)
    return corr_x0, corr_T, normF


if __name__ == '__main__':
    from csltk.utilities import emSystem
    from csltk.correctors import Continuation

    x0cr3bp, T, _ = resonant_orbit(emSystem, 3, 4, 0.7853)
    # print(x0cr3bp[[0,4]],T)
    # x0cr3bp = np.array([0.24793994,0,0,0,2.35003695,0])
    # T = 25.251478076037266

    # 2:1
    # x0cr3bp = np.array([0.19987, 0, 0, 0, 2.56951, 0])
    # T = 27.23629*3600*24/emSystem.tstar

    corrX0, corrT, _ = SingleShooter.variable_time(np.hstack([x0cr3bp, T]), emSystem)
    soln = cr3bp.propagate(emSystem, corrX0, np.array([0, corrT]), dense=True)
    # familiy_initial_conditions = Continuation.contruct_family(x0cr3bp,T,emSystem,10)

    #
    familiy_initial_conditions = Continuation.psuedo_arclength(np.hstack([corrX0, corrT]), emSystem,
                                                               10, direction=1)
    #
    ax = emSystem.plot_system()
    plt.sca(ax)
    ax.plot(soln.y[0, :], soln.y[1, :], soln.y[2, :])
    # plt.show()
    #
    #
    for init_conds in familiy_initial_conditions:
        halo = cr3bp.propagate(emSystem, init_conds[0:6], np.array([0, init_conds[-1]]),
                               np.sort(np.linspace(0, init_conds[-1], 500)))
        ax.plot(halo.y[0, :], halo.y[1, :], halo.y[2, :])
    plt.show()
