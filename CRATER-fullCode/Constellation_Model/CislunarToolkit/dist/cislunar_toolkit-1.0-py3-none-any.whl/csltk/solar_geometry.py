import numpy as np
import spiceypy as spice
from csltk.utilities import emSystem

# Ephemeris data:
# Kernel path shouldn't include '-' or spaces (idk why but just move it to a good nice directory)
KERNEL = '../Spice/Archive/sckernel.tm'
spice.furnsh(KERNEL)


def get_ephemeris(target, obs, ref, et, abcorr='NONE'):
    x, t = spice.spkezr(target, et, ref, abcorr, obs)
    x = np.atleast_1d(np.array(x)).T
    t = np.array(t)
    r, v = x[0:3], x[3:6]
    return r, v, t


def get_em_dcm(et):
    # Position of moon relative to EM Barycenter in J2000 frame
    r_moon_em, v_moon_em, t = get_ephemeris('MOON', 'EARTH-MOON BARYCENTER', 'J2000', et)
    b_1_hat = r_moon_em / np.linalg.norm(r_moon_em)

    b_3 = np.cross(r_moon_em, v_moon_em) / np.linalg.norm(np.cross(r_moon_em, v_moon_em))
    b_3_hat = b_3.T / np.linalg.norm(b_3)

    b_2_hat = np.cross(b_3_hat, b_1_hat)

    return np.array([b_1_hat.T, b_2_hat.T, b_3_hat.T])


# sun_vec = get_sun_uvec(spice.str2et('2022-01-01 00:00:00.00 UTC'))
def get_sun_uvec(et):
    DCM = get_em_dcm(et)
    # position of sun relative to em barycenter:
    r_sun_em, v_sun_em, t = get_ephemeris('SUN', 'EARTH-MOON BARYCENTER', 'J2000', et)
    r_sun_hat = r_sun_em / np.linalg.norm(r_sun_em)
    return DCM @ r_sun_hat


# # Function for calculating apparent magnitude of object as seen from an observer in cislunar space
# def calc_apparent_mag(d, a_spec, a_diff, obj, obs, sun, system: emSystem):
#     if is_occluded(obj, obs, sun, system):
#         # Return False if object is not visible from occlusion
#         return None
#     elif not is_illuminated(obj, obs, sun, system):
#         return None
#     else:
#         d = d / system.r
#         v = obj - obs
#         zeta = np.linalg.norm(v)
#         psi = np.arccos(np.dot(v, sun) / np.linalg.norm(v))
#         p_diff = 2 / (3 * np.pi) * (np.sin(psi) + (np.pi - psi) * np.cos(psi))
#         m_sun = -26.74
#         m_obj = m_sun - 2.5 * np.log10(d ** 2 / zeta ** 2 * (a_spec / 4 + a_diff * p_diff))
#         return m_obj


# Function for determining if object is occluded by a body in cislunar spcae (earth or moon)
def is_occluded(obj, obs, sun, system: emSystem, sun_constraint=30, moon_constraint=5, earth_constraint=5):
    earth = np.array([-system.mu, 0, 0])
    moon = np.array([1 - system.mu, 0, 0])
    e = earth - obs
    m = moon - obs
    v = obj - obs
    r_E = system.r1
    r_M = system.r2
    r = system.lstar
    eps = np.arcsin((r_E / r) / np.linalg.norm(e))
    zeta = np.arcsin((r_M / r) / np.linalg.norm(m))

    if np.abs(np.arccos(np.dot(e, v) / (np.linalg.norm(e) * np.linalg.norm(v)))) <= eps + np.deg2rad(earth_constraint):
        # Check Earth LOS occlusion + 5 deg
        return True
    elif np.abs(np.arccos(np.dot(m, v) / (np.linalg.norm(m) * np.linalg.norm(v)))) <= zeta + np.deg2rad(moon_constraint):
        # Moon LOS occlusion + 5 deg
        return True
    elif np.abs(np.arccos(np.dot(-sun, v) / np.linalg.norm(v))) <= np.deg2rad(sun_constraint):
        # Sun occlusion
        return True
    else:
        return False


# Function for determining if object is illuminated by the suns rays (or if it is in the earth or moon's shadow)
def is_illuminated(obj, obs, sun, system: emSystem):
    earth = np.array([-system.mu, 0, 0])
    moon = np.array([1 - system.mu, 0, 0])
    e = earth - obj
    m = moon - obj
    r_E = system.r1
    r_M = system.r2
    r = system.lstar

    if (np.linalg.norm(np.cross(sun, -e)) > r_E / r or np.dot(sun, -e) < 0) and \
            (np.linalg.norm(np.cross(sun, -m)) > r_M / r or np.dot(sun, -m) < 0):
        return True
    else:
        return False