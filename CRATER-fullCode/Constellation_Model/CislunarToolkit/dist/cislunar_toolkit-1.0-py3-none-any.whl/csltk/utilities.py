import numpy as np
import astropy as ap
import scipy.integrate
from scipy import interpolate as interp
from astropy import constants as const
from astropy import units as u
import matplotlib.pyplot as plt
from dataclasses import dataclass, InitVar


@dataclass
class Planet:
    name: str
    mu: float
    a: float
    r: float
    short_name: InitVar[str] = None


    def __post_init__(self, short_name=None):
        self.short_name = short_name


# Mass (kg), semimajor axis (km), radius (km), abbreviation:
Earth = Planet('Earth', 398600.435436, 149597871, 6371.0087714, 'E')
Moon = Planet('Moon', 4902.800066, 384338.174, 0.2724880 * 6371.0087714, 'M')
Sun = Planet('Sun', 132712440041.93938, 0, 695700, 'S')


class System:

    def __init__(self, **kwargs):
        if len(kwargs) == 2:

            p1 = kwargs['P1']
            p2 = kwargs['P2']
            if p1.mu < p2.mu:
                # Smaller primary always is P2
                p11 = p1
                p1 = p2
                p2 = p11

            self.p1 = p1
            self.p2 = p2
            self.r1 = p1.r
            self.r2 = p2.r
            self.mu = self.p2.mu / (self.p2.mu + self.p1.mu)
            self.lstar = self.p2.a
            self.tstar = np.sqrt(self.lstar ** 3 / (self.p1.mu + self.p2.mu))
        else:
            self.mu = kwargs['mu']
            self.lstar = kwargs['lstar']
            self.tstar = kwargs['tstar']

        self.find_libration_points()
    
    @property
    def period(self):
        return 2*np.pi*self.tstar

    def find_libration_points(self, tol_steps=100, tol=1E-20):
        # State vector
        libration_points = np.zeros([5, 6])

        # Define co-linear derivatives
        UPrime = lambda x: x - ((1 - self.mu) * (x + self.mu)) / (
                np.abs(x + self.mu) ** 3) - (self.mu * (x - 1 + self.mu)) / (np.abs(x - 1 + self.mu) ** 3)
        UPPrime = lambda x: 1 + (2 * self.mu) / (((self.mu - 1 + x) ** 2) ** (3 / 2)) - (2 * (self.mu - 1)) / (
                ((self.mu + x) ** 2) ** (3 / 2))

        # Newton's method to find equilibrium points
        xi1 = (1 - self.mu) / 2  # L1 initial guess
        xi2 = 1 + 3.5 * self.mu  # L2 initial guess
        xi3 = -self.mu - 0.25  # L3 initial guess

        xi = np.array([[xi1, xi2, xi3]]).T
        diff = np.array([[1, 1, 1]]).T
        step = 1
        while all(diff > tol) and (step < tol_steps):
            xi_prev = xi
            xi = xi - UPrime(xi) / UPPrime(xi)

            diff = np.abs(xi - xi_prev)
            step += 1

        libration_points[0:3, 0] = np.squeeze(xi)
        libration_points[3, 0] = 0.5 - self.mu
        libration_points[4, 0] = 0.5 - self.mu
        libration_points[3, 1] = np.sqrt(3) / 2
        libration_points[4, 1] = -np.sqrt(3) / 2

        self.li = libration_points

    def plot_system(self, axlim=[]):
        ax = plt.axes(projection='3d')
        ax.scatter3D(-self.mu, 0, 0, s=60, c='green')  # Plot Earth
        ax.scatter3D(1 - self.mu, 0, s=45, c='gray')  # Plot Moon
        ax.scatter3D(self.li[:, 0], self.li[:, 1], self.li[:, 2], c='magenta')
        if axlim:
            ax.set_xlim(axlim) # equal aspect ratio
            ax.set_ylim(axlim)
            ax.set_zlim(axlim)
        return ax


emSystem = System(**{'P1': Earth, 'P2': Moon})


class rotate:

    @staticmethod
    def intertial_to_rotating(x0, t, t0=0, sys=emSystem):
        x0[0:3] = x0[0:3] / sys.lstar
        x0[3:] = x0[3:] * sys.tstar / sys.lstar
        rotMatPos = np.array(
            [[np.cos(t - t0), np.sin(t - t0), 0], [-np.sin(t - t0), np.cos(t - t0), 0], [0, 0, 1]])
        rotMatVel = np.array(
            [[-np.sin(t - t0), -np.cos(t - t0), 0], [np.cos(t - t0), -np.sin(t - t0), 0], [0, 0, 1]])
        rotMat = np.hstack([np.vstack([rotMatPos, rotMatVel]), np.vstack([np.zeros([3, 3]), rotMatPos])])
        return np.linalg.inv(rotMat).dot(x0) - np.array([emSystem.mu, 0, 0, 0, 0, 0])

    @staticmethod
    def rotating_to_inertial(x0, t, t0=0, sys=emSystem):
        rotMatPos = np.array(
            [[np.cos(t - t0), np.sin(t - t0), 0], [-np.sin(t - t0), np.cos(t - t0), 0], [0, 0, 1]])
        rotMatVel = np.array(
            [[-np.sin(t - t0), -np.cos(t - t0), 0], [np.cos(t - t0), -np.sin(t - t0), 0], [0, 0, 1]])
        rotMat = np.hstack([np.vstack([rotMatPos, rotMatVel]), np.vstack([np.zeros(3), rotMatPos])])
        return (rotMat.dot(x0)) * sys.lstar


def find_equal_arclength_nodes(p0Soln,n_nodes):
    # Adapted from 'interparc' for matlab
    # https://www.mathworks.com/matlabcentral/fileexchange/34874-interparc

    pass




if __name__ == '__main__':
    print(emSystem.mu)
    print(emSystem.li)
    # sys = System(Earth, Moon)
    # sys.plot_system()

    # rotate.intertial_to_rotating()
