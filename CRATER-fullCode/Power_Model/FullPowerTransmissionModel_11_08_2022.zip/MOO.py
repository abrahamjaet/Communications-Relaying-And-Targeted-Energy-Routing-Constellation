import math
import numpy as np
import matplotlib.pyplot as plt
from dataclasses import dataclass
from csltk.jpl_query import JPLFamily
from csltk import cr3bp
from csltk.utilities import System
import pickle
import itertools
import orbitDict
from os import listdir
from os.path import isfile, join

# https://stackoverflow.com/questions/28965734/general-bars-and-stars
def partitions(n, k):
    for c in itertools.combinations(range(n+k-1), k-1):
        yield [b-a-1 for a, b in zip((-1,)+c, c+(n+k-1,))]

def reorder(lst, newIdx):
    pos = newIdx #lst.index(first)
    return lst[pos:] + lst[:pos]





sys = System(mu=0.01215058560962404, lstar=389703.2648292776, tstar=382981.2891290545)
ax = sys.plot_system()
orbitFiles = [f for f in listdir('trajectories') if isfile(join('trajectories', f))]
orbit = []
orbitNumber = []
numOrbits = 0
for i in range(len(orbitFiles)):
    filename = 'trajectories/' + orbitFiles[i]
    orbit.append(orbitDict.chosenOrbits.load(filename))
    orbitNumber.append(numOrbits)
    numOrbits += 1
   


numOrbitsSimul = 10
numSat = 3

## total number of satellites at once 
for i in range(1, numSat):
    ## total number of orbits at once
    for j in range(1, i):
        # every combination of orbits given total orbits at once (j)
        for combination in itertools.combinations(orbitNumber, j):
            currOrbits = []
            # extract all orbits in given combination of orbits
            for k in combination:
                currOrbits.append(orbit[k])    
            # iterate through all possible distributions of satellites into current orbit combo
            for config in partitions(i, j):
                allTrajectories = []
                for sats in range(len(config)):
                    # don't send in orbits if 0 sats in that orbit
                    if config[sats] != 0:
                        # starting index step size for multiple orbits
                        shiftParameter = int(len(currOrbits[sats].x)/config[sats])
                        # for m in range(sats):
                        #     allX = reorder(list(currOrbits[sats].x), shiftParameter*m)
                        #     allY = reorder(list(currOrbits[sats].y), shiftParameter*m)
                        #     allZ = reorder(list(currOrbits[sats].z), shiftParameter*m)
                        #     allTrajectories.append((allX, allY, allZ))
                    else:
                        currOrbits[sats] = None
                
                ## send info into functions

                    




# const = len(orbit.x)/numSat
# pos1 = initPos
# pos2 = x[const], y[const]
# pos3 = x[const*2], y[const*2]


