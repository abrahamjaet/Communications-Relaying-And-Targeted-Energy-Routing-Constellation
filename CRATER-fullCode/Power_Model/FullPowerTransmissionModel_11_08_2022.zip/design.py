import numpy as np 
import orbitDict 

class designConfiguration: 

    def __init__(self,ID, orbits, numSats, totSats, batterySize, solarPanelSize, laserPower, apetRad, receiverRad_power, diameter_TxM, diameterTxO, freq, dataRate, dataRate_ED):
        self.id = ID 
        self.orbits = orbits # All orbits (family, trajectory, velocity, period, percent eclipsed) in current design
        self.numSats = numSats # Number of satellites on each orbit
        self.totSats = totSats # Total number of satellites in constellation 
        self.batterySize = batterySize # Battery mass [kg]
        self.solarPanel = solarPanelSize # Solar panel area [m^2]
        self.laserPower = laserPower # Wattage required to power the laser [W]
        self.apetureRad = apetRad # radius of output lens on SC [m]
        self.receiverRad_power = receiverRad_power # radius of ground receiver [m]
        self.diameter_TxM = diameter_TxM # antenna diameter of the receiver on the moon [m]
        self.diameterTxO = diameterTxO # antenna diameter of the receiver on the satellite [m]
        self.freq = freq # frequency [Hz]
        self.dataRate = dataRate # desired lunar data rate [bps]
        self.dataRate_ED = dataRate_ED # desired data rate for earth downlink [bps]
        self.commsObj = []
        self.powerObj = []
        self.roiObj = []
    
    # def add_orbit(self, obj):
    #     self.orbits.append(obj) 


    def add_commsObj(self,score):
        self.commsObj = score 
    
    def add_powerObj(self,score):
        self.powerObj = score
    
    def add_roiObj(self,score): 
        self.roiObj = score 
