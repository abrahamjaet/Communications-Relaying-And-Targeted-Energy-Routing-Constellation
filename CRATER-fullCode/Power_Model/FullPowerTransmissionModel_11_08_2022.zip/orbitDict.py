import pickle 

class chosenOrbits:
    number: int
    family: str
    x: list[float]
    y: list[float]
    z: list[float]
    vx: list[float]
    vy: list[float]
    vz: list[float]
    T: float
    eclipse: float

    def __init__(self, number, family, x, y, z, vx, vy, vz, T, eclipse):
        self.number = number
        self.family =  family
        self.x = x
        self.y = y
        self.z = z
        self.vx = vx
        self.vy = vy 
        self.vz = vz 
        self.T = T
        self.eclipse = eclipse
    # def __init__(self, family, x, y, z, vx, vy, vz, T,i):
    #     self[i].family =  family
    #     self[i].x = x
    #     self[i].y = y
    #     self[i].z = z
    #     self[i].vx = vx
    #     self[i].vy = vy 
    #     self[i].vz = vz 
    #     self[i].T = T
    #     self.numOrbits = i +1
    def __repr__(self):
        return "Orbit: %s" % self.s
    def save(self, fileName):
        """Save thing to a file."""
        f = open(fileName,"wb")
        pickle.dump(self,f)
        f.close()
    def load(fileName):
        """Return a thing loaded from a file."""
        f = open(fileName,"rb")
        obj = pickle.load(f)
        f.close()
        return obj
    # make load a static method
    load = staticmethod(load)


if __name__ == "__main__":
    # code for standalone use
    foo = chosenOrbits("foo")
    foo.save("foo.pickle")
